<?php

require_once("require/connection.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Our Posts </title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>

<h1 class=" shadow bg-primary-subtle text-dark text-center fw-bold p-3 m-3 rounded-1 ">Our Latest Posts</h1>

<?php

$query = "SELECT * FROM post";
$result = mysqli_query($connection,$query);

if ($result) {
	while ($row =mysqli_fetch_assoc($result)) {


?>

<div class="container-fluid">
	<div class="row">
		
	<div class="col-12">
		
 <div class="card shadow m-5 text-center">
  <img src="https://plus.unsplash.com/premium_photo-1663040197283-fae88b360dad?q=80&w=1470&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-id fw-bold"><?php echo $row['post_id']; ?></h5>
    <h5 class="card-title fw-bold"><?php echo $row['post_title']; ?></h5>
    <p class="card-text lead"><?php echo $row['summary']; ?></p>
  </div>
</div>
	</div>
	</div>
</div>















<?php

	}
}

?>



<!-- <div class="row">
        <div class="col-lg-12 text-center p-4 bg-dark text-light mt-5" style="max-width: 100%;">
          Copyright By .Tariq 2024 | 2050 All rights resserved
        </div>
  </div> -->
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>