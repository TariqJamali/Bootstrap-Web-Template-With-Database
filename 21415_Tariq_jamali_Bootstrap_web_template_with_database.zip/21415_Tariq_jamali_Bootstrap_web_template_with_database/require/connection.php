<?php

mysqli_report(false);

$connection = mysqli_connect("localhost", "root", "", "pagination");

if (mysqli_connect_errno()) {

	echo "Error No" .mysqli_connect_errno();
	echo "<br/>";
	echo "Error Message" .mysqli_connect_error();
	
}












?>