<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Bootstrap Web Template With Database</title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
</head>
<body>
  <nav class="navbar navbar-expand-lg bg-body- bg-primary-subtle shadow p-1">
  <div class="container-fluid">
    <a id="home" class="navbar-brand fw-bold fs-2" href="#">.Tariq</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 fw-bold">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#home">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#about-us">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#our-team">Our Team</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#contact-us">Contact Us</a>
        </li>
         <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="our_posts.php">Our Posts</a>
        </li>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-dark" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
<div class="contaner mt-4 shadow" style="width: 100%;">
<div id="carouselExampleAutoplaying" class="carousel slide rounded-1"  data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images.pexels.com/photos/120049/pexels-photo-120049.jpeg?auto=compress&cs=tinysrgb&w=100% 100vh" class="d-block w-100 rounded-1 " alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/1366957/pexels-photo-1366957.jpeg?auto=compress&cs=tinysrgb&w=100% 100vh" class="d-block w-100 rounded-1" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://images.pexels.com/photos/2049422/pexels-photo-2049422.jpeg?auto=compress&cs=tinysrgb&w=100% 100vh" class="d-block w-100 rounded-1" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>
<div class="card mt-5 shadow" style="max-width: 100%;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="https://www.shutterstock.com/image-photo/businesswoman-pressing-customer-service-support-600nw-542206567.jpg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h1 id="about-us" class="card-title text-center fw-bold">About Us</h1>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Odio, aperiam, sint numquam sed, non optio nemo a, vitae dolore distinctio deserunt similique dolorem quisquam maxime possimus iusto? Quidem, earum, possimus?
        Quasi at delectus aliquam ipsum, veniam vel earum voluptas consequatur. Perferendis, rerum quos totam enim repellendus atque impedit quis, praesentium, a, labore similique provident? Praesentium numquam debitis accusantium quas, adipisci.
        Eos illo excepturi ex minus quisquam inventore cumque ipsa rem fuga. Minima doloremque quaerat ut sequi veritatis, fuga autem dolores nam dignissimos mollitia sint excepturi, ipsa voluptatibus earum tempora error.
        Adipisci cum sint assumenda magni deserunt excepturi a recusandae incidunt ad officia libero blanditiis reprehenderit repellendus dolor deleniti voluptatibus harum esse pariatur, laborum ipsum! Dolore recusandae voluptas, quod deserunt magni.
        Perspiciatis, unde architecto non officiis delectus necessitatibus, quas natus saepe suscipit ducimus soluta dolorem tenetur. Architecto rem assumenda unde officiis error nam, illum sit asperiores aliquam adipisci excepturi obcaecati minima! Lorem ipsum, dolor sit amet consectetur adipisicing, elit. Quaerat voluptatem cum ipsa incidunt impedit voluptate ut quidem nemo dolor, eaque id sunt ipsum molestias ea excepturi magni doloribus officiis alias.blanditiis reprehenderit repellendus dolor deleniti voluptatibus harum esse pariatur, laborum ipsum! Dolore recusandae voluptas, quod deserunt magni.
        Perspiciatis, unde architecto non officiis delectus necessitatibus, quas natus saepe suscipit ducimus soluta dolorem tenetur. 
       </p>
      </div>
    </div>
  </div>
</div>
<section id="team" class="team section-padding lead lg-shahdow">
  <div class="container-fluid shadow mt-5 rounded-1 ">
    <div class="row">
      <div class="col-md-12">
        <div class="section-header text-center pt-5 ">
          <h2 id="our-team" class=" fw-bold fs-1">Our Team</h2>
<div class="container shadow">
  <div class="row ">
  <div class="card col-12 col-md-6 col-lg-4">
  <img class="card-img-top rounded-circle" src="image/t-1.jpg " alt="Card image cap">
  <div class="card-body">
  <h5 class="card-title py-2 text-center fw-bold">Amelia</h5>
  <p class="card-text">Front-end Developer</p>
  </div>
</div>

 <div class="card col-12 col-md-6 col-lg-4">
  <img class="card-img-top rounded-circle" src="image/t-2.jpg" alt="Card image cap">
  <div class="card-body">
  <h5 class="card-title py-2 text-center fw-bold">Jack</h5>
  <p class="card-text ">PHP Developer</p>
  </div>
</div>

 <div class="card col-12 col-md-6 col-lg-4">
  <img class="card-img-top rounded-circle" src="image/t-3.jpg" alt="Card image cap">
  <div class="card-body">
  <h5 class="card-title py-2 text-center fw-bold">Isabella</h5>
  <p class="card-text">Full Stack Developer</p>
  </div>
</div>
</div>
</div>
  </div>
      </div>
    </div>
  </div>
</section> 
<div class="container-fluid mt-5">
  <div class="row ">
<h1 id="contact-us" class=" p-3 text-center fw-bold mt-5"> Contact Us </h1>
<form class="p-2">
  <div class="form-row mt-5">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Email</label>
      <input type="email" class="form-control" id="inputEmail4" placeholder="Email">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Password</label>
      <input type="password" class="form-control" id="inputPassword4" placeholder="Password">
    </div>
  </div>
  <div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Message</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" class="form-control" id="inputCity">
    </div>
  </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary shadow">Send</button>
</form>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
        <div class="col-lg-12 text-center p-4 bg-dark bg-gradient text-light mt-5" style="max-width: 100%;">
          Copyright By .Tariq 2024 | 2050 All rights resserved
        </div>
  </div>
</div>
	<script type="text/javascript" src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>