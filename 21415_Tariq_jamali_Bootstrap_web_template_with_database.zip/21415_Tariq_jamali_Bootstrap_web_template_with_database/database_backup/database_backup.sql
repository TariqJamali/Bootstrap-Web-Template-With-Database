/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.32-MariaDB : Database - pagination
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pagination` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `pagination`;

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(25) NOT NULL,
  `summary` longtext NOT NULL,
  `description` longtext NOT NULL,
  `author` varchar(25) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`post_title`,`summary`,`description`,`author`) values 
(1,'post one','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Ramey'),
(2,'post two','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','John'),
(3,'post three','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Harry'),
(4,'post four','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Sherry'),
(5,'post five','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','William'),
(6,'post six','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Nelson'),
(7,'post seven','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Trump'),
(8,'post eight','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','John'),
(9,'post nine','In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus in nunc sed felis fringilla fringilla eu non dui. Vestibulum tempus pharetra mauris eget pretium. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nunc efficitur neque sed neque eleifend, et egestas felis molestie. Mauris gravida velit eget commodo tempor. Donec at magna a augue pharetra posuere vitae sed ex. Suspendisse erat metus, finibus at commodo quis, consequat sed tellus. Pellentesque convallis feugiat interdum. Nullam auctor elementum commodo. Vivamus in rhoncus nibh. Ut vulputate consequat ornare.','Sherry');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
